(* Paclet Info File *)

(* created 2013.05.16*)

Paclet[
  Name -> "AmbitStochastics",
  Version -> "0.0.1",
  MathematicaVersion -> "6+",
  Extensions -> {
    {"Documentation", Language -> "English"}
}]