(* Mathematica Package *)

(* Created by the Wolfram Workbench May 16, 2013 *)

BeginPackage["AmbitStochastics`"]
(* Exported symbols added here with SymbolName::usage *) 

Begin["`Private`"]
(* Implementation of the package *)



End[]

EndPackage[]

